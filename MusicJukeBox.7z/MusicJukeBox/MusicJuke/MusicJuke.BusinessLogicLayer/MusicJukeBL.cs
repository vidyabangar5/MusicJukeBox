﻿using MusicJuke.DataAccessLayer;
using MusicJuke.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicJuke.BusinessLogicLayer
{
    public class MusicJukeBL
    {
        MusicJukeDAL dl = new MusicJukeDAL();
        public bool Register(IGUser gUser)
        {
            return dl.Register(gUser);
        }
        public bool LogIn(string username, string password)
        {
            return dl.LogIn(username, password);
        }
        public Album ViewAlbumByID(int albumID)
        {
            return dl.ViewAlbumByID(albumID);
        }
        public Song ViewSongByID(int songID)
        {
            return dl.ViewSongByID(songID);
        }
        public DataTable SearchByAlbumName(string albumname)
        {
            return dl.SearchByAlbumName(albumname);
        }
        public DataTable SearchBySongName(string songname)
        {
            return dl.SearchBySongName(songname);
        }
        public DataTable SearchBySinger(string singer)
        {
            return dl.SearchBySinger(singer);
        }
        public void Download(string songname, string link)
        {
            dl.Download(songname,link);
        }
        public DataTable SearchUser(int userid)
        {
            return dl.SearchUser(userid);
        }
        public bool DeleteAlbum(int albumid)
        {
            return dl.DeleteAlbum(albumid);
        }
        public bool UpdateAlbum(Album album)
        {
            return dl.UpdateAlbum(album);
        }
        public bool DeleteUser(int userid)
        {
            return dl.DeleteUser(userid);
        }
        public bool RemoveMusic(int songid)
        {
            return dl.RemoveMusic(songid);
        }
        public bool UploadMusic(Song song)
        {
            return dl.UploadMusic(song);
        }
        public bool DeleteAlbumIdFromSong(int songid)
        {
            return dl.DeleteAlbumIdFromSong(songid);
        }
    }
}
