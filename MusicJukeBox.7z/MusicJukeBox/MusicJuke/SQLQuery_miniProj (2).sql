use Training_19Sep18_Pune
go
create schema Music_Box
go
create table Music_Box.UserTable (UserID int identity(1,1) primary key, Name varchar(200), UserName varchar(50), Address varchar(250), DOB date, City varchar(50), Password varchar(50), MobileNo bigint, Admin bit not null)
create table Music_Box.Album (AlbumID int identity(1,1) primary key, AlbumName varchar(50), Category varchar(50), No_Of_Songs int, [Release Date] date , Company varchar(50), Price money, Language varchar(50))
create table Music_Box.Songs (SongID int identity(1,1) primary key, SongName varchar(100), Singer varchar(100), Movie varchar(200), ComposedBy varchar(100), Lyrics varchar(600), Year int, AlbumID int references Music_Juke_Box.Album(AlbumID), Language varchar(50), link varchar(300))
 

 ----- ==============: STORE PROCEDURES :===============
---- COMMON

alter proc Music_Box.usp_Common_Login(
@username varchar(50),
@password varchar(50),
@uid int out,
@name varchar(200) out,
@admin bit out
)
as 
begin
	select @uid=UserID, @name=Name,@admin=Admin 
	from Music_Box.UserTable where UserName=@username and Password=@password
end


create proc Music_Box.usp_Common_Register(
@name varchar(200),
@username varchar(50),
@address varchar(250),
@dob date,
@city varchar(50),
@password varchar(50),
@mobile bigint,
@admin bit
)
as
begin
	insert into Music_Box.UserTable values(@name,@username,@address,@dob,@city,@password,@mobile,@admin)
end


alter proc Music_Box.usp_Common_ViewAlbumByID(
@albumid int,
@albumname varchar(50) out,
@category varchar(50) out,
@noofsongs int out,
@releasedate date out,
@company varchar(50) out,
@price money out,
@language varchar(50) out
)
as
begin
	select @albumname=AlbumName,@category=Category,@noofsongs=No_Of_Songs,@releasedate=[Release Date],@company=Company,@price=Price,@language=Language
	from Music_Box.Album where AlbumID=@albumid
end


alter proc Music_Box.usp_Common_ViewSongByID(
@songid int,
@songname varchar(100) out,
@singer varchar(100) out,
@movie varchar(200) out,
@composedBy varchar(100) out,
@albumid int out,
@lyrics varchar(600) out,
@year int out, 
@language varchar(50) out, 
@link varchar(300) out
)
as
begin
	select @songname=SongName, @singer=Singer, @movie=Movie, @composedBy=ComposedBy, @albumid=AlbumID, @lyrics=Lyrics, @year=Year,@language=Language, @link=link
	from Music_Box.Songs 
	where SongID=@songid
end


create proc Music_Box.usp_Common_SearchByAlbumName(
@albumname varchar(50)
)
as
begin
	select * from Music_Box.Album where AlbumName=@albumname
end


alter proc Music_Box.usp_Common_SearchBySongName(
@songname varchar(100)
)
as
begin
	select * from Music_Box.Songs  where SongName=@songname
end



create proc Music_Box.usp_Common_SearchBySinger(
@singer varchar(100)
)
as
begin
	select * from Music_Box.Songs  where Singer=@singer
end


---- USER PROCEDURE

alter proc Music_Box.usp_User_DownloadSong(
@songid int,
@link varchar(300) out
)
as
begin
	select @link=link from Music_Box.Songs  where SongID=@songid
end





